﻿using BookPortal.Data;
using BookPortal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookPortal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly ApplicationDbContext dbContext;
        public BooksController(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult GetAllBooks()
        {
            var allBooks = dbContext.Books.ToList();
            return Ok(allBooks);
        }

        [HttpPost]
        public IActionResult AddBook(AddBookDTO addBookDTO)
        {
            var bookEntity = new Book() {
                Author = addBookDTO.Author,
                Title = addBookDTO.Title,
                ISBN = addBookDTO.ISBN,
                PublishedDate = addBookDTO.PublishedDate   
            };

            dbContext.Books.Add(bookEntity);
            dbContext.SaveChanges();
            return Ok(bookEntity);
        }

        [HttpGet]
        [Route("{id:guid}")]
        public IActionResult GetBookById(Guid id) { 
            var book = dbContext.Books.Find(id);    
            if(book == null) { return NotFound(); }
            return Ok(book); 
        }

        [HttpPut]
        [Route("{id:guid}")]
        public IActionResult UpdateBookById(Guid id,UpdateBookDTO updateBookDTO)
        {
            var book = dbContext.Books.Find(id);
            if(book is null) { return NotFound(); }
            book.Author = updateBookDTO.Author;
            book.Title = updateBookDTO.Title;
            book.ISBN = updateBookDTO.ISBN;
            book.PublishedDate = updateBookDTO.PublishedDate;
            dbContext.SaveChanges();
            return Ok(book);
        }

        [HttpDelete]
        [Route("{id:guid}")]
        public IActionResult DeleteBookById(Guid id)
        {
            var book = dbContext.Books.Find(id);
            if(book is null) { return NotFound();}
            dbContext.Books.Remove(book);
            dbContext.SaveChanges();
            return Ok();
        }
    }
}
